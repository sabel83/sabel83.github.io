/*
	Unicode <-> char conversion
	Written by Abel Sinkovics
*/
#ifndef CONVERSION_H
#define CONVERSION_H

#include <stdlib.h>
#include <windows.h>

wchar_t *char_to_wchar(const char *s);
char *wchar_to_char(const wchar_t *s);

char *read_from_registry(HKEY key, const char *key_name, const char *value_name);


#endif
