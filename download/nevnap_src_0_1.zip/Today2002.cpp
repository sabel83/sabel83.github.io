/*
	Written by Abel Sinkovics
	Version: 0.1
*/

#include <stdio.h>
#include <windows.h>  // Standard Header
#include <todaycmn.h> // Today API
#include <aygshell.h> // Shell Functions
#include "conversion.h"

#define MAX_STRING_LEN 1024
#define MARGO 4

const TCHAR g_szWndClass[] = _T("myToday2002ItemWnd");
TCHAR g_String0[MAX_STRING_LEN] = {0};
TCHAR g_String1[MAX_STRING_LEN] = {0};
TCHAR g_String2[MAX_STRING_LEN] = {0};

HINSTANCE g_hInstance = NULL;

class Nev {
public:
	char *nev;

	struct Nev *next;
public:
	Nev(const char *s) : next(0) {
		if (s) {
			int l = strlen(s)+1;
			nev = (char*)malloc(l);
			memcpy(nev, s, l);
		} else
			nev = 0;
	}
	~Nev() {
		if (nev) free(nev);
		if (next) delete next;
	}
};

Nev *nevek[12][31];
int ev_kint=0, ho_kint=0, nap_kint=0;

void nevek_tolt()
{
	for (int i=0; i<12; ++i)
		for (int j=0; j<31; ++j) {
			nevek[i][j] = 0;
		}

	// Az adatfile neve
	char *file_name = read_from_registry(HKEY_CURRENT_USER, "Software\\AbelSoft\\Nevnap", "DataFile");

	// Betoltjuk a filet
	FILE *f = fopen(file_name, "rb");
	if (file_name) free(file_name);

	if (f) {
		while (!feof(f)) {
			// Beolvasunk egy sort
			char sor[1025];
			char *s_ho=sor, *s_nap=0, *nev=0;
			int i=0;
			while (!feof(f) && i<MAX_STRING_LEN) {
				sor[i] = (char)(unsigned char)fgetc(f);
				if (feof(f) || sor[i]==10 || sor[i]==13) {
					break;
				} else {
					if (sor[i]==' ') {
						sor[i]=0;
						if (s_nap) {
							if (!nev) nev = sor+i+1;
						} else {
							s_nap = sor+i+1;
						}
					}
				}
				++i;
			}
			sor[i] = 0;

			// Feldolgozzuk
			int ho = atoi(s_ho)-1;
			if (ho>=0 && ho<12) {
				int nap = atoi(s_nap)-1;
				if (nap>=0 && nap<31) {
					Nev *n = new Nev(nev);
					n->next = nevek[ho][nap];
					nevek[ho][nap] = n;
				}
			}
		}
		fclose(f);
	}
}

void nevek_torol()
{
	for (int i=0; i<12; ++i)
		for (int j=0; j<31; ++j) {
			delete nevek[i][j];
			nevek[i][j] = 0;
		}
}

char *print_nap_nevek(char *s, int ho, int nap)
{
	char *c = s;
	for (Nev *n = nevek[ho-1][nap-1]; n;n=n->next) if (n->nev) {
		if (c==s) sprintf(c, "%s", n->nev);
		 else sprintf(c, ", %s", n->nev);
		while (*c) ++c;
	}
	
	if (c==s) {
		sprintf(s, "Nincs adat");
		while (*c) ++c;
	}
	return c;
}

bool szokoev(int ev)
{
	return (ev % 4) && (!(ev % 100) || (ev % 400));
}

int ho_hossz(int ev, int ho) {
	switch (ho) {
	case 1:
	case 3:
	case 5:
	case 7:
	case 8:
	case 10:
	case 12:
		return 31;
	case 4:
	case 6:
	case 9:
	case 11:
		return 30;
	case 2:
		if (szokoev(ev)) return 29;
		 else return 28;
	}
	return 0;
}

void nap_vissza(int ev, int &ho, int &nap)
{
	if (nap==1) {
		if (ho==1) ho=12;
		 else --ho;
		nap = ho_hossz(ev, ho);
	} else
		--nap;
}

void nap_elore(int ev, int &ho, int &nap)
{
	if (nap>=ho_hossz(ev, ho)) {
		if (ho==12) ho=1;
		 else ++ho;
		nap = 1;
	} else
		++nap;
}

void display_string_frissit()
{
	char s[MAX_STRING_LEN];

	// Mai datum
	SYSTEMTIME t;
	GetLocalTime(&t);

	ev_kint = t.wYear;
	ho_kint = t.wMonth;
	nap_kint = t.wDay;

	int ho = t.wMonth;
	int nap = t.wDay;

	nap_vissza(t.wYear, ho, nap);
	char *c = s;
	sprintf(c, "Tegnap: "); while (*c) ++c;
	c = print_nap_nevek(c, ho, nap);
	MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, s, -1, g_String0, MAX_STRING_LEN);

	ho = t.wMonth;
	nap = t.wDay;
	c = s;
	sprintf(c, "Ma: "); while (*c) ++c;
	c = print_nap_nevek(c, ho, nap);
	MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, s, -1, g_String1, MAX_STRING_LEN);

	nap_elore(t.wYear, ho, nap);
	c = s;
	sprintf(c, "Holnap: "); while (*c) ++c;
	c = print_nap_nevek(c, ho, nap);
	MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, s, -1, g_String2, MAX_STRING_LEN);
}

HWND APIENTRY InitializeCustomItem(TODAYLISTITEM *ptli, HWND hParent)
{
	HWND hwnd = NULL;

	if(ptli->fEnabled)
	{
		hwnd = CreateWindow(g_szWndClass, _T(""), WS_VISIBLE | WS_CHILD,
			0, 0, GetSystemMetrics(SM_CXSCREEN), 0, 
			hParent, NULL, g_hInstance, NULL);

	}
	return hwnd;
}

BOOL APIENTRY CustomItemOptionsDlgProc(HWND hwnd, UINT msg, UINT wParam, 
	LONG lParam)
{
	switch(msg) 
	{
		case WM_INITDIALOG:
		{
			SHINITDLGINFO shidi;
			shidi.dwMask = SHIDIM_FLAGS;
			shidi.hDlg = hwnd;
			shidi.dwFlags = SHIDIF_DONEBUTTON | SHIDIF_SIZEDLGFULLSCREEN;
			SHInitDialog(&shidi);
		}
		break;
		case WM_COMMAND:
			switch(LOWORD(wParam)) 
			{
				case IDOK:
					EndDialog(hwnd, LOWORD(wParam));
				break;
			}
		break;
		default:
			return FALSE;
   }
   return TRUE;
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch(msg) 
	{
		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hwnd, &ps);

			COLORREF crText = SendMessage(GetParent(hwnd), TODAYM_GETCOLOR, TODAYCOLOR_TEXT, 0);
			SetTextColor(hdc, crText);

			RECT rcClient;
			GetClientRect(hwnd, &rcClient);

			rcClient.top += MARGO;
			rcClient.bottom -= MARGO;
			rcClient.left += MARGO;
			rcClient.right -= MARGO;

			SetBkMode(hdc, TRANSPARENT);

			RECT r;
			int h = (rcClient.bottom - rcClient.top) / 3;
			r.left = rcClient.left;
			r.right = rcClient.right;
			
			r.top = rcClient.top;
			r.bottom = r.top + h;
			
			DrawText(hdc, g_String0, -1, &r, DT_WORDBREAK);

			r.top = r.bottom;
			r.bottom += h;

			DrawText(hdc, g_String1, -1, &r, DT_WORDBREAK);

			r.top = r.bottom;
			r.bottom += h;

			DrawText(hdc, g_String2, -1, &r, DT_WORDBREAK);

			EndPaint(hwnd, &ps);
		}
		break;
		case WM_ERASEBKGND:
		{
			TODAYDRAWWATERMARKINFO dwi;

			dwi.hwnd = hwnd;
			dwi.hdc = (HDC)wParam;

			GetClientRect(hwnd, &dwi.rc);
			SendMessage(GetParent(hwnd), TODAYM_DRAWWATERMARK, 0, 
				(LPARAM)&dwi);
		}
		return TRUE;
		case WM_LBUTTONUP:

		break;
		case WM_TODAYCUSTOM_QUERYREFRESHCACHE:
		{
			int h = MARGO*2;

			BOOL bUpdated = FALSE;

			// Datum ellenorzes
			SYSTEMTIME t;
			GetLocalTime(&t);

			bUpdated = ev_kint!=t.wYear || ho_kint!=t.wMonth || nap_kint!=t.wDay;
			if (bUpdated) display_string_frissit();

			TODAYLISTITEM *ptli = (TODAYLISTITEM*)wParam;

			RECT rcText = {0, 0, GetSystemMetrics(SM_CXSCREEN), 0};

			HDC hdc = GetDC(hwnd);

			DrawText(hdc, g_String0, -1, &rcText, DT_WORDBREAK | DT_CALCRECT);
				h += rcText.bottom*3;

			ReleaseDC(hwnd, hdc);

			if(ptli->cyp != (ULONG)h)
			{
				ptli->cyp = h;
				bUpdated = TRUE;
			}

			return bUpdated;
		}
		break;
		case WM_TODAYCUSTOM_CLEARCACHE:
			// Here you can free up any additional resources 
			// that you may have allocated, such as bitmaps.
		break;
		default:
			return DefWindowProc(hwnd, msg, wParam, lParam);
	}
	return 0;
}

BOOL WINAPI DllMain(HANDLE hInstance, DWORD dwReason, LPVOID pvUnused)
{
	switch(dwReason)
	{
		case DLL_PROCESS_ATTACH:
		{
			g_hInstance = (HMODULE)hInstance;

			WNDCLASS wc;
			ZeroMemory(&wc, sizeof(wc));

			wc.style = CS_HREDRAW | CS_VREDRAW;
			wc.lpfnWndProc = (WNDPROC)WndProc;
			wc.hInstance = g_hInstance;
			wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
			wc.lpszClassName = g_szWndClass;

			nevek_tolt();

			return (RegisterClass(&wc) != NULL);
		}
		break;
		case DLL_PROCESS_DETACH:
		{
			UnregisterClass(g_szWndClass, g_hInstance);
			nevek_torol();
		}
		break;
	}
	return FALSE;
}
