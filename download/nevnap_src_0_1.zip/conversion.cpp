/*
	Unicode <-> char conversion
	Written by Abel Sinkovics
*/
#include "conversion.h"

/* Conversion */
wchar_t *char_to_wchar(const char *s)
{
	int len;
	wchar_t *ss;

	if (!s) return 0;

	len = MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, s, -1, ss, 0);
	if (len>0) ss = (wchar_t*)malloc(sizeof(wchar_t*)*len);
	 else ss = 0;
	MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, s, -1, ss, len);

	return ss;
}

char *wchar_to_char(const wchar_t *s)
{
	int len;
	char *ss;

	if (!s) return 0;

	len = WideCharToMultiByte(CP_ACP, 0, s, -1, ss, 0, "*", FALSE) + 1;
	if (len>0) ss = (char*)malloc(len);
	 else ss = 0;
	WideCharToMultiByte(CP_ACP, 0, s, -1, ss, len, "*", FALSE);

	return ss;
}


char *read_from_registry(HKEY key, const char *key_name, const char *value_name)
{
	wchar_t *key_Name = char_to_wchar(key_name);
	wchar_t *value_Name = char_to_wchar(value_name);
	char *result = 0;

	HKEY hKey = NULL;
	DWORD dwDisposition = 0;
	if (RegCreateKeyEx(key, key_Name, 
		0, NULL, 0, KEY_ALL_ACCESS, NULL, &hKey, &dwDisposition
		) != ERROR_SUCCESS)  {
		if (key_Name) free(key_Name);
		if (value_Name) free(value_Name);
		return result;
	}

	DWORD dwType = REG_SZ;
	DWORD dwDataSize = 0;

	if (RegQueryValueEx(hKey, value_Name, 0, &dwType, (PBYTE)NULL, &dwDataSize)==ERROR_SUCCESS) 
	{
		TCHAR *buff = (TCHAR*)malloc(sizeof(TCHAR)*dwDataSize);

		if (buff) {
			RegQueryValueEx(hKey, value_Name, 0, &dwType, (PBYTE)buff, &dwDataSize);
			result = wchar_to_char(buff);
			free(buff);
		}
	}

	RegCloseKey(hKey);

	if (key_Name) free(key_Name);
	if (value_Name) free(value_Name);
	return result;
}
